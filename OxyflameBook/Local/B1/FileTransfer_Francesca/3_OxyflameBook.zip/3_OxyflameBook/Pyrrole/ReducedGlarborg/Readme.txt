Reference:	Chen2023 - mechanism from SM (dashed lines)
Detailed:	ITV-Base-Chemistry + Reduced Glarborg + C4H5N (dotted lines)
New:		ITV-Compact + Reduced Glarborg + C4H5N (solid lines)