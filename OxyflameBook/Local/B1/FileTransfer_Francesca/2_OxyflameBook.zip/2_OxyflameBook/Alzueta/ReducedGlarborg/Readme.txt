Reference:	ITV-Base-Chemistry + CRECK-NOx (dashed lines)
Detailed:	ITV-Base-Chemistry + Reduced Glarborg + C5H5N (dotted lines)
New:		ITV-Base-Chemistry + Modified Reduced Glarborg + C5H5N (solid lines)