Reference:	ITV-Base-Chemistry (dashed lines)
New:		ITV-Compact (coal+biomass) (solid lines)