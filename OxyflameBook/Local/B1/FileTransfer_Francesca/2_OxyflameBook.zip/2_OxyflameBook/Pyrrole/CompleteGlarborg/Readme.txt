Reference:	Chen2023 - mechanism from SM (dashed lines)
Detailed:	ITV-Base-Chemistry + Complete Glarborg + C4H5N (dotted lines)
New:		ITV-Compact + Complete Glarborg + C4H5N (solid lines)